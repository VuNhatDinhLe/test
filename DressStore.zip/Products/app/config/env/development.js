module.exports = {
    db: 'mongodb://localhost/mmongodb://localhost:27017/DressStore',
    sessionSecret: 'developmentSessionSecret'
    };