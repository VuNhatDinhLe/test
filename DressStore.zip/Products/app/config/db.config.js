module.exports = {
   // url: "mongodb://localhost:27017/DressStore"
    //ATLAS_URI=mongodb + srv://Blessing:crLlpnzOKuPjUPvz@cluster0.pzwkbe4.mongodb.net/tutorials?retryWrites=true&w=majority;
     //url:"mongodb+srv://Blessing:crLlpnzOKuPjUPvz@cluster0.pzwkbe4.mongodb.net/Tutorial?retryWrites=true&w=majority"
//mongodb+srv://aafterschool11:Cabasa123@cluster0.ar24enw.mongodb.net/
  //url:"mongodb+srv://Bless:I7P2ONAc9WkTuzzB@cluster0.ioseuy1.mongodb.net/SportsStore?retryWrites=true&w=majority"
      url:"mongodb+srv://aafterschool11:Cabasa123@cluster0.ar24enw.mongodb.net/DressStore?retryWrites=true&w=majority"
};